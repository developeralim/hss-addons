<?php

namespace HerSuitespotAddons\Addons;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

use AddonSelect;
use Elementor\Widget_Base;
use Elementor\Core\Base\Document;
use ElementorPro\Modules\LoopBuilder\Documents\Loop as LoopDocument;
use ElementorPro\Modules\QueryControl\Controls\Template_Query;
use ElementorPro\Modules\QueryControl\Module as QueryControlModule;
use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use PostsSelectControl;
use TermSelectControl;

class CustomPostsGroupingByCategories extends Widget_Base
{
    const LOAD_MORE_ON_CLICK = 'load_more_on_click';
	const LOAD_MORE_INFINITE_SCROLL = 'load_more_infinite_scroll';

    private $product_query_control_args;

    public function get_name()
    {
        return 'custom-posts-grouping-by-category';
    }

    public function get_title()
    {
        return esc_attr('Custom Post Grouping By Category');
    }

    public function get_icon()
    {
        return 'eicon-posts-masonry';
    }

    public function get_categories()
    {
        return ['HerSuitespot'];
    }

    public function get_keywords()
    {
        return [
            'post listing',
            'resource listing',
            'custom post type listing',
            'listing with filter'
        ];
    }

    public function get_style_depends()
    {
        return [
            'font-awesome',
            'font-awesome-5-all',
            'font-awesome-4-shim',
            'dashicons',
            'addon-style'
        ];
    }

    public function get_script_depends()
    {
        return ['addon-script','infinite-scroll'];
    }

    public function register_controls()
    {
        $this->register_layout_control();
        $this->register_query_control();
        $this->register_pagination_section_controls();
        $this->register_styles_controls();

    }

    private function register_styles_controls()
    {
        $this->start_controls_section(
			'post_group_heading_section',
			[
				'label' => esc_attr( 'Title'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'selector' => '{{WRAPPER}} .cpt-group-heading',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .cpt-group-heading',
			]
		);

        $this->add_control(
			'heading_text_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cpt-group-heading' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'heading_margin',
			[
				'label' => esc_html__( 'Margin', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default' => [
					'top' => 2,
					'right' => 0,
					'bottom' => 2,
					'left' => 0,
					'unit' => 'em',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .cpt-group-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'heading_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default' => [
					'top' => 2,
					'right' => 0,
					'bottom' => 2,
					'left' => 0,
					'unit' => 'em',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .cpt-group-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .cpt-group-heading',
			]
		);

        $this->end_controls_section();
    }

    private function register_query_control() {
		$this->start_controls_section(
			'section_query',
			array(
				'label'     => esc_attr( 'Query'),
			)
		);

        $this->add_control(
			'source',
			array(
				'label'        => esc_attr('Source'),
				'type'         => Controls_Manager::SELECT,
				'render_type'  => 'template',
				'options'      => array_merge(['' => esc_attr('None')],get_post_types(array(
                    'public'   => true,
                    '_builtin' => false
                ))),
				'default'      => 'default',
			)
		);

        $this->add_control(
			'taxonomy',
			array(
				'label'        => esc_attr('Title Taxonomy'),
				'type'         => Controls_Manager::SELECT,
				'render_type'  => 'template',
				'options'      => [],
			)
		);


		$this->add_control(
			'terms_filter_rules',
			array(
				'label'     => esc_attr( 'Terms Filter Rule'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'IN',
				'options'   => array(
					'include' => esc_attr( 'Match Terms'),
					'exclude' => esc_attr( 'Exclude Terms'),
				)
			)
		);

        $this->add_control(
			'terms',
			array(
				'label'     => esc_attr( 'Select Terms'),
				'type'      => TermSelectControl::SELECT2,
                'default'   => 'solid',
				'multiple'  => true,
				'options'   => [],
			)
		);

		$this->add_control(
			'post_filter',
			array(
				'label'     => esc_attr( 'Posts Filter'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'post__not_in',
				'options'   => array(
					'post__in'     => esc_attr( 'Match Posts'),
					'post__not_in' => esc_attr( 'Exclude Posts'),
				),
			)
		);

		$this->add_control(
			'posts',
			array(
				'label'     => esc_attr( 'Select Posts'),
				'type'      => PostsSelectControl::SELECT2,
				'multiple'  => true,
				'options'   => [],
			)
		);

		$this->add_control(
			'offset',
			array(
				'label'       => esc_attr( 'Offset'),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'description' => esc_attr( 'Set the starting index.'),
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'     => esc_attr( 'Order by'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'term_id',
				'options'   => array(
					'name'       => esc_attr( 'Name'),
					'term_id'    => esc_attr( 'ID'),
					'count'      => esc_attr( 'Posts Count'),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'     => esc_attr( 'Order'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'desc',
				'options'   => array(
					'desc' => esc_attr( 'Descending'),
					'asc'  => esc_attr( 'Ascending'),
				),
			)
		);

		$this->end_controls_section();
	}


    private function register_layout_control()
    {
        $this->start_controls_section(
			'section_layout',
			[
				'label' => esc_attr('Layout'),
			]
		);

		$this->add_control(
			'template_id',
			[
				'label' => esc_attr('Choose a template'),
				'type' => Template_Query::CONTROL_ID,
				'label_block' => true,
				'autocomplete' => [
					'object' => QueryControlModule::QUERY_OBJECT_LIBRARY_TEMPLATE,
					'query' => [
						'post_status' => Document::STATUS_PUBLISH,
						'meta_query' => [
							[
								'key' => Document::TYPE_META_KEY,
								'value' => LoopDocument::get_type(),
								'compare' => 'IN',
							],
						],
					],
				],
				'actions' => [
					'new' => [
						'visible' => true,
						'document_config' => [
							'type' => LoopDocument::get_type(),
						],
					],
					'edit' => [
						'visible' => true,
					],
				],
				'frontend_available' => true,
			]
		);

        $this->add_responsive_control('column',array(
            'label'   => esc_attr('Select column in a row'),
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                '1' => 1,
                '2' => 2,
                '3' => 3,
                '4' => 4,
                '5' => 5,
                '6' => 6,
                '7' => 7,
                '8' => 8,
                '9' => 9,
                '10' => 10,
                '11' => 11,
                '12' => 12
            ),
            'desktop_default'  => '4',
            'tablet_default'   => '3',
            'mobile_default'   => '2',
            'default'          => '4'
        ));

		$this->end_controls_section();
    }

    private function register_pagination_section_controls()
    {
        $this->start_controls_section(
			'section_pagination',
			[
				'label' => esc_attr('Pagination'),
			]
		);

		$this->add_control(
			'pagination_type',
			[
				'label' => esc_attr('Pagination'),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->get_pagination_type_options(),
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'pagination_page_limit',
			[
				'label' => esc_attr('Page Limit'),
				'default' => '5',
				'condition' => [
					'pagination_type!' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
						'',
					],
				],
			]
		);

		$this->add_control(
			'pagination_numbers_shorten',
			[
				'label' => esc_attr('Shorten'),
				'type' => Controls_Manager::SWITCHER,
				'default' => '',
				'condition' => [
					'pagination_type' => [
						'numbers',
						'numbers_and_prev_next',
					],
				],
			]
		);

		$this->add_control(
			'pagination_prev_label',
			[
				'label' => esc_attr('Previous Label'),
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_attr('&laquo; Previous'),
				'condition' => [
					'pagination_type' => [
						'prev_next',
						'numbers_and_prev_next',
					],
				],
			]
		);

		$this->add_control(
			'pagination_next_label',
			[
				'label' => esc_attr('Next Label'),
				'default' => esc_attr('Next &raquo;'),
				'condition' => [
					'pagination_type' => [
						'prev_next',
						'numbers_and_prev_next',
					],
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'pagination_align',
			[
				'label' => esc_attr('Alignment'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_attr('Left'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_attr('Center'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_attr( 'Right'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .PAGINATION-CLASS' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'pagination_type!' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
						'',
					],
				],
			]
		);

		$this->add_control(
			'pagination_individual_divider',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'pagination_type' => [
						'numbers',
						'numbers_and_prev_next',
						'prev_next',
					],
				],
			]
		);

		$this->add_control(
			'pagination_individual_handle',
			[
				'label' => esc_attr( 'Individual Pagination'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_attr( 'On'),
				'label_off' => esc_attr( 'Off'),
				'default' => '',
				'condition' => [
					'pagination_type' => [
						'numbers',
						'numbers_and_prev_next',
						'prev_next',
					],
				],
			]
		);

		$this->add_control(
			'pagination_individual_handle_message',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_attr( 'For multiple Posts Widgets on the same page, toggle this on to control the pagination for each individually. Note: It affects the page\'s URL structure.'),
				'content_classes' => 'elementor-control-field-description',
				'condition' => [
					'pagination_type' => [
						'numbers',
						'numbers_and_prev_next',
						'prev_next',
					],
				],
			]
		);

		$this->add_control(
			'load_more_spinner',
			[
				'label' => esc_attr( 'Spinner'),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-spinner',
					'library' => 'fa-solid',
				],
				'exclude_inline_options' => [ 'svg' ],
				'recommended' => [
					'fa-solid' => [
						'spinner',
						'cog',
						'sync',
						'sync-alt',
						'asterisk',
						'circle-notch',
					],
				],
				'skin' => 'inline',
				'label_block' => false,
				'condition' => [
					'pagination_type' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
					],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'heading_load_more_button',
			[
				'label' => esc_attr( 'Button'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'pagination_type' => 'load_more_on_click',
				],
			]
		);

		$this->register_button_content_controls( [
			'button_text' => esc_attr( 'Load More'),
			'control_label_name' => esc_attr( 'Button Text'),
			'prefix_class' => 'load-more-align-',
			'alignment_default' => 'center',
			'section_condition' => [
				'pagination_type' => 'load_more_on_click',
			],
			'exclude_inline_options' => [ 'svg' ],
		] );

		$this->remove_control( 'button_type' );
		$this->remove_control( 'link' );
		$this->remove_control( 'size' );

		$this->add_control(
			'heading_load_more_no_posts_message',
			[
				'label' => esc_attr( 'No More Posts Message'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'pagination_type' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
					],
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_responsive_control(
			'load_more_no_posts_message_align',
			[
				'label' => esc_attr( 'Alignment'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => esc_attr( 'Left'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_attr( 'Center'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_attr( 'Right'),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_attr( 'Justified'),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => '--load-more-message-alignment: {{VALUE}};',
				],
				'condition' => [
					'pagination_type' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
					],
				],
			]
		);

		$this->add_control(
			'load_more_no_posts_message_switcher',
			[
				'label' => esc_attr( 'Custom Messages'),
				'type' => Controls_Manager::SWITCHER,
				'default' => '',
				'condition' => [
					'pagination_type' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
					],
				],
			]
		);

		$this->add_control(
			'load_more_no_posts_custom_message',
			[
				'label' => esc_attr( 'No more posts message'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_attr( 'No more posts to show'),
				'condition' => [
					'pagination_type' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
					],
					'load_more_no_posts_message_switcher' => 'yes',
				],
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();


		// Pagination style controls for prev/next and numbers pagination.
		$this->start_controls_section(
			'section_pagination_style',
			[
				'label' => esc_attr( 'Pagination'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pagination_type!' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
						'',
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pagination_typography',
				'selector' => '{{WRAPPER}} .PAGINATION-CLASS',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
			]
		);

		$this->add_control(
			'pagination_color_heading',
			[
				'label' => esc_attr( 'Colors'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs( 'pagination_colors' );

		$this->start_controls_tab(
			'pagination_color_normal',
			[
				'label' => esc_attr( 'Normal'),
			]
		);

		$this->add_control(
			'pagination_color',
			[
				'label' => esc_attr( 'Color'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-pagination .page-numbers:not(.dots)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'pagination_color_hover',
			[
				'label' => esc_attr( 'Hover'),
			]
		);

		$this->add_control(
			'pagination_hover_color',
			[
				'label' => esc_attr( 'Color'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-pagination a.page-numbers:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'pagination_color_active',
			[
				'label' => esc_attr( 'Active'),
			]
		);

		$this->add_control(
			'pagination_active_color',
			[
				'label' => esc_attr( 'Color'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-pagination .page-numbers.current' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'pagination_spacing',
			[
				'label' => esc_attr( 'Space Between'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'separator' => 'before',
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'max' => 100,
					],
					'em' => [
						'max' => 10,
					],
					'rem' => [
						'max' => 10,
					],
				],
				'selectors' => [
					'body:not(.rtl) {{WRAPPER}} .cpt-gp-pagination .page-numbers:not(:first-child)' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 );',
					'body:not(.rtl) {{WRAPPER}} .cpt-gp-pagination .page-numbers:not(:last-child)' => 'margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'body.rtl {{WRAPPER}} .cpt-gp-pagination .page-numbers:not(:first-child)' => 'margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'body.rtl {{WRAPPER}} .cpt-gp-pagination .page-numbers:not(:last-child)' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 );',
				],
			]
		);

		$this->add_responsive_control(
			'pagination_spacing_top',
			[
				'label' => esc_attr( 'Spacing'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'max' => 100,
					],
					'em' => [
						'max' => 10,
					],
					'rem' => [
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-pagination' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

		// Pagination style controls for on-load pagination with type on-click/infinity-scroll.
		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_attr( 'Pagination'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pagination_type' => [
						'load_more_on_click',
						'load_more_infinite_scroll',
					],
				],
			]
		);

		$this->register_load_more_button_style_controls();

		$this->register_load_more_message_style_controls();

		$this->end_controls_section();
    }

    public function register_load_more_button_style_controls() {
		$this->add_control(
			'heading_load_more_style_button',
			[
				'label' => esc_attr( 'Button'),
				'type' => Controls_Manager::HEADING,
				'condition' => [
					'pagination_type' => 'load_more_on_click',
				],
			]
		);

		$this->register_button_style_controls( [
			'section_condition' => [
				'pagination_type' => 'load_more_on_click',
			],
		] );
	}

	public function register_load_more_message_style_controls() {
		$this->add_control(
			'heading_load_more_on_click_no_posts_message',
			[
				'label' => esc_attr( 'No More Posts Message'),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'pagination_type' => 'load_more_on_click',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'heading_load_more_on_click_infinity_scroll_no_posts_message',
			[
				'label' => esc_attr( 'No More Posts Message'),
				'type' => Controls_Manager::HEADING,
				'condition' => [
					'pagination_type' => 'load_more_infinite_scroll',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'load_more_no_posts_message',
				'selector' => '{{WRAPPER}} .e-load-more-message',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
			]
		);

		$this->add_control(
			'load_more_no_posts_message_color',
			[
				'label' => esc_attr( 'Color'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}' => '--load-more-message-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'load_more_spinner_color',
			[
				'label' => esc_attr( 'Spinner Color'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}' => '--load-more-spinner-color: {{VALUE}};',
				],
				'separator' => 'before',
				'condition' => [
					'load_more_spinner[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'load_more_spacing',
			[
				'label' => esc_attr( 'Spacing'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'max' => 50,
					],
					'em' => [
						'max' => 5,
					],
					'rem' => [
						'max' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => '--load-more—spacing: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
	}

    protected function register_button_style_controls( $args = [] ) {
		$default_args = [
			'section_condition' => [],
		];

		$args = wp_parse_args( $args, $default_args );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .cpt-gp-button',
				'condition' => $args['section_condition'],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}} .cpt-gp-button',
				'condition' => $args['section_condition'],
			]
		);

		$this->start_controls_tabs( 'tabs_button_style', [
			'condition' => $args['section_condition'],
		] );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => esc_attr( 'Normal'),
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => esc_attr( 'Text Color'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-button' => 'fill: {{VALUE}}; color: {{VALUE}};',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .cpt-gp-button',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'global' => [
							'default' => Global_Colors::COLOR_ACCENT,
						],
					],
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => esc_attr( 'Hover'),
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'hover_color',
			[
				'label' => esc_attr( 'Text Color'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-button:hover, {{WRAPPER}} .cpt-gp-button:focus' => 'color: {{VALUE}};',
					'{{WRAPPER}} .cpt-gp-button:hover svg, {{WRAPPER}} .cpt-gp-button:focus svg' => 'fill: {{VALUE}};',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button_background_hover',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .cpt-gp-button:hover, {{WRAPPER}} .cpt-gp-button:focus',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' => esc_attr( 'Border Color'),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-button:hover, {{WRAPPER}} .cpt-gp-button:focus' => 'border-color: {{VALUE}};',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_attr( 'Hover Animation'),
				'type' => Controls_Manager::HOVER_ANIMATION,
				'condition' => $args['section_condition'],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .cpt-gp-button',
				'separator' => 'before',
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => esc_attr( 'Border Radius'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .cpt-gp-button',
				'condition' => $args['section_condition'],
			]
		);

		$this->add_responsive_control(
			'text_padding',
			[
				'label' => esc_attr( 'Padding'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
				'condition' => $args['section_condition'],
			]
		);
	}

    protected function register_button_content_controls( $args = [] ) {
		$default_args = [
			'section_condition' => [],
			'button_text' => esc_attr( 'Click here'),
			'control_label_name' => esc_attr( 'Text'),
			'prefix_class' => 'elementor%s-align-',
			'alignment_default' => '',
			'exclude_inline_options' => [],
		];

		$args = wp_parse_args( $args, $default_args );

		$this->add_control(
			'button_type',
			[
				'label' => esc_attr( 'Type'),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => esc_attr( 'Default'),
					'info' => esc_attr( 'Info'),
					'success' => esc_attr( 'Success'),
					'warning' => esc_attr( 'Warning'),
					'danger' => esc_attr( 'Danger'),
				],
				'prefix_class' => 'elementor-button-',
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'text',
			[
				'label' => $args['control_label_name'],
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => $args['button_text'],
				'placeholder' => $args['button_text'],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_attr( 'Link'),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => esc_attr( 'https://your-link.com'),
				'default' => [
					'url' => '#',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_attr( 'Alignment'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => esc_attr( 'Left'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_attr( 'Center'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_attr( 'Right'),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_attr( 'Justified'),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'prefix_class' => $args['prefix_class'],
				'default' => $args['alignment_default'],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'size',
			[
				'label' => esc_attr( 'Size'),
				'type' => Controls_Manager::SELECT,
				'default' => 'sm',
				'options' => self::get_button_sizes(),
				'style_transfer' => true,
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'selected_icon',
			[
				'label' => esc_attr( 'Icon'),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin' => 'inline',
				'label_block' => false,
				'condition' => $args['section_condition'],
				'exclude_inline_options' => $args['exclude_inline_options'],
			]
		);

		$this->add_control(
			'icon_align',
			[
				'label' => esc_attr( 'Icon Position'),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left' => esc_attr( 'Before'),
					'right' => esc_attr( 'After'),
				],
				'condition' => array_merge( $args['section_condition'], [ 'selected_icon[value]!' => '' ] ),
			]
		);

		$this->add_control(
			'icon_indent',
			[
				'label' => esc_attr( 'Icon Spacing'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'max' => 50,
					],
					'em' => [
						'max' => 5,
					],
					'rem' => [
						'max' => 5,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cpt-gp-button .elementor-align-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .cpt-gp-button .elementor-align-icon-left' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			'button_css_id',
			[
				'label' => esc_attr( 'Button ID'),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'ai' => [
					'active' => false,
				],
				'default' => '',
				'title' => esc_attr( 'Add your custom id WITHOUT the Pound key. e.g: my-id'),
				'description' => esc_attr( 'Please make sure the ID is unique and not used elsewhere on the page this form is displayed. This field allows `A-z 0-9` & underscore chars without spaces.'),
				'separator' => 'before',
				'condition' => $args['section_condition'],
			]
		);
	}

    public static function get_button_sizes() {
		return [
			'xs' => esc_attr( 'Extra Small'),
			'sm' => esc_attr( 'Small'),
			'md' => esc_attr( 'Medium'),
			'lg' => esc_attr( 'Large'),
			'xl' => esc_attr( 'Extra Large'),
		];
	}

    protected function get_pagination_type_options() {
		return [
			'' => esc_attr( 'None'),
			// 'numbers' => esc_attr( 'Numbers'),
			// 'prev_next' => esc_attr( 'Previous/Next'),
			// 'numbers_and_prev_next' => esc_attr( 'Numbers') . ' + ' . esc_attr( 'Previous/Next'),
			// self::LOAD_MORE_ON_CLICK => esc_attr( 'Load on Click'),
			self::LOAD_MORE_INFINITE_SCROLL => esc_attr( 'Infinite Scroll'),
		];
	}

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $column                                = $settings['column'];
        $column_mobile                         = $settings['column_mobile'] ?? $column;
        $column_tablet                         = $settings['column_tablet'] ?? $column;
        $template_id                           = $settings['template_id'];
        $terms_filter_rules                    = $settings['terms_filter_rules'];
        $order                                 = $settings['order'];
        $orderby                               = $settings['orderby'];
        $offset                                = $settings['offset'];
        $load_more_spinner                     = implode(" ",$settings['load_more_spinner'] ?? []);
        $taxonomy                              = $settings['taxonomy'];
        $terms                                 = $settings['terms'];
        $posts                                 = $settings['posts'];
        $post_filter                           = $settings['post_filter'];
        $load_more_no_posts_custom_message     = $settings['load_more_no_posts_custom_message'];
        $load_more_no_posts_message_switcher   = $settings['load_more_no_posts_message_switcher'];
        $load_more_no_posts_message_align      = $settings['load_more_no_posts_message_align'];
        $pagination_type                       = $settings['pagination_type'];
        $source                                = $settings['source'];


        $script = json_encode( compact(
            'column',
            'column_mobile',
            'column_tablet',
            'template_id',
            'terms_filter_rules',
            'order',
            'orderby',
            'load_more_spinner',
            'taxonomy',
            'terms',
            'terms',
            'posts',
            'post_filter',
            'load_more_no_posts_custom_message',
            'load_more_no_posts_message_switcher',
            'load_more_no_posts_message_align',
            'pagination_type',
            'source',
            'offset'
        ));

        echo <<< SCRIPT
            <script>
                var ctpElementorSettings = $script;
            </script>
        SCRIPT;

        echo <<< TEXT
            <div class='cpt-group-wrap' data-settings=''>
                <span class='loader {$load_more_spinner}'></span>
            </div>
        TEXT;
    }
}
