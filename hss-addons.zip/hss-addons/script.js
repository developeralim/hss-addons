

jQuery(function ($) {
    // Retrieve settings
    let $cptWrapper = $('.cpt-group-wrap');
    let settings = $cptWrapper.data('settings');


    $.fn.infiniteScroll = function ( settings ) {

        var InfScroll = function (container) {
            this.container = container
            this.loadingCategory    = false;
            this.categoryLimit      = 1;
            this.categoryOffset     = 0;
            this.hasMoreCategory    = true;
            this.postsLimit         = settings.offset;
            this.initPostOffset     = this.postsLimit;
            this.postsOffset        = this.initPostOffset;
            this.currentTermId  = 0;
            this.loadMorePosts      = false;
            this.loadingPosts       = false;
            this.childOf            = null;
        };

        InfScroll.prototype.init = function () {

            this.rewindCategories();

            $(window).scroll((e) => {
                let bottom = this.container.get(0).getBoundingClientRect().bottom;

                if (bottom <= (window.scrollY + window.innerHeight)) {
                    this.rewind();
                }
            });

            return this;
        }

        InfScroll.prototype.rewind = function () {
            if (!this.loadingCategory && this.hasMoreCategory) {
                this.rewindCategories();
            }

            if (!this.loadingPosts && this.loadMorePosts) {
                this.rewindPosts();
            }
        }

        // Rewind categories
        InfScroll.prototype.rewindCategories = function () {
            let data = {
                action         : 'load_categories',
                offset         : this.categoryOffset,
                postsOffset    : this.postsOffset,
                postsLimit     : this.postsLimit,
                initPostOffset : this.initPostOffset,
                taxonomy       : settings.taxonomy,
                order          : settings.order,
                orderby        : settings.orderby,
                terms_filter   : settings.terms_filter_rules,
                terms          : settings.terms,
                post_type      : settings.post_type,
                template_id    : settings.template_id,
                column         : this.getColumn()
            }

            if (this.childOf) {
                data.child_of = this.childOf;
            }

            $.ajax({
                url: `${addon.ajax}`,
                type: 'GET',
                data: data,
                beforeSend: () => {
                    this.loadingCategory = true;
                    this.postsOffset = this.initPostOffset;
                    this.container.find('.loader').show();
                },
                complete: () => {
                    this.container.find('.loader').hide();
                },
                success: (response) => {

                    try {

                        let { category_id, data, offset, has_more } = response.data

                        this.hasMoreCategory = has_more;
                        this.categoryOffset = offset;
                        this.currentTermId = category_id;

                        if (data) {
                            this.container.find('.loader').before(data);
                        }

                        this.rewindPosts();

                    } catch (error) {
                        console.error(error);
                    }
                }
            });
        }


        // Rewind posts
        InfScroll.prototype.rewindPosts = async function () {

            let data = {
                action         : 'load_more_posts',
                offset         : this.postsOffset,
                limit          : this.postsLimit,
                term           : this.currentTermId,
                post_type      : settings.post_type,
                taxonomy       : settings.taxonomy,
                post_filter    : settings.post_filter,
                posts          : settings.posts,
                template_id    : settings.template_id,
                column         : this.getColumn()
            }

            $.ajax({
                url: `${addon.ajax}`,
                type: 'GET',
                data: data,
                beforeSend: () => {
                    this.loadingPosts = true;
                    this.container.find('.loader').show();
                },
                complete: () => {
                    this.loadingPosts = false;
                    this.container.find('.loader').hide();
                },
                success: (response) => {

                    const { has_more, data, offset } = response.data;

                    this.loadMorePosts = has_more;
                    this.postsOffset = offset;

                    if (data) {
                        this.container.find('.loader').before(data);
                    }

                    if (false === has_more) {
                        this.loadingCategory = false;
                    }
                }
            });
        }

        InfScroll.prototype.getColumn   = function(){

            if ( window.innerWidth >= 1400 || window.innerWidth >= 992 ) {
                return settings.column;
            }

            if ( window.innerWidth >= 768 ) {
                return settings.column_tablet;
            }

            if ( window.innerWidth >= 576 ) {
                return settings.column_mobile;
            }

            return 12;
        }

        return (new InfScroll(this)).init();
    }

    $cptWrapper.infiniteScroll( ctpElementorSettings  );

    // Load taxonomies by selected post types
});


(function (factory) {
    jQuery(document).ready(function () {
        typeof elementor !== 'undefined' && factory(jQuery);
    });
}(function ($) {

    elementor.channels.editor.on('section:activated', (sectionName, panel) => {
        if (sectionName == 'section_query') {

            var loadTaxonomy = function (type) {
                $.ajax({
                    url: `${addon.ajax}?action=get_taxonomies&post_type=${type}`,
                    type: 'GET',
                    success: function (response) {
                        panel.$el.find('[data-setting="taxonomy"]').html(response);
                    }
                })
            };

            if ((type = panel.$el.find('[data-setting="source"]').val()) !== "") {
                loadTaxonomy(type);
            }

            panel.$el.find('[data-setting="source"]').off().on('change', function () {

                loadTaxonomy($(this).val());
            });
        }
    });

    var filterTerms = elementor.modules.controls.Select2.extend({

        isUpdated: false,

        onReady: function () {
            this.$el.find('[data-setting="terms"]').select2({
                placeholder : "Start Typing...",
                ajax        : {
                    url   : `${addon.ajax}?action=load_terms`,
                    delay : 250,
                    data: function (params) {
                        return {
                            q         : params.term,
                            taxonomy  : elementor.panel.$el.find('[data-setting="taxonomy"]').val()
                        };
                    },
                    processResults: function (data, params) {
                        return {
                            results : $.map(data.data,term => {
                                console.log(term);
                                return {
                                    text : term.name,
                                    id   : term.term_id
                                }
                            })
                        };
                    }
                },
                minimumInputLength: 1,
                cache: true
            })
        },

        onBeforeDestroy: function () {
            if (this.ui.select.data('select2')) {
                // this.ui.select.select2('destroy');
            }

            this.$el.remove();
        }
    });

    elementor.addControlView("terms-select", filterTerms);

    var filterPosts = elementor.modules.controls.Select2.extend({

        isUpdated: false,

        onReady: function () {
            this.$el.find('[data-setting="posts"]').select2({
                placeholder : "Start Typing...",
                ajax        : {
                    url   : `${addon.ajax}?action=load_posts`,
                    delay : 250,
                    data: function (params) {
                        return {
                            q         : params.term,
                            taxonomy  : elementor.panel.$el.find('[data-setting="taxonomy"]').val(),
                            post_type : elementor.panel.$el.find('[data-setting="source"]').val(),
                            terms     : elementor.panel.$el.find('[data-setting="terms"]').val()
                        };
                    },
                    processResults: function (data, params) {
                        return {
                            results : $.map(data.data,post => {
                                return {
                                    text : post.post_title,
                                    id   : post.ID
                                }
                            })
                        };
                    }
                },
                minimumInputLength: 1,
                cache: true
            })
        },

        onBeforeDestroy: function () {
            if (this.ui.select.data('select2')) {
                // this.ui.select.select2('destroy');
            }

            this.$el.remove();
        }
    });

    elementor.addControlView("posts-select", filterPosts);

}));
