<?php

/**
 * Plugin Name: HerSuiteSpot Addons
 * Plugin URI: #
 * Description: Custom Elementor Addons for HerSuiteSpot
 * Author: Developer Alim
 * Author URI: https://github.com/developeralim
 * Version: 1.0.0
 * Text Domain: hss-addon
 * Domain Path: /languages
 * Network: True
 *
 */

use HerSuitespotAddons\Addons\CustomPostsGroupingByCategories;

if (!defined('ABSPATH')) {
    die('Kangaroos cannot jump here');
}


add_action('wp_enqueue_scripts','register_scripts');
add_action('admin_enqueue_scripts','register_scripts');

function register_scripts()
{
    wp_register_style( 'addon-style',trailingslashit( plugin_dir_url(__FILE__) ) . 'style.css' );
    wp_register_script( 'addon-script',trailingslashit( plugin_dir_url(__FILE__) ) . 'script.js',['jquery'] );

    wp_localize_script('addon-script','addon',[
        'ajax' => admin_url('admin-ajax.php')
    ]);
}

add_action('plugins_loaded',function(){

    add_action('wp_head',function(){
        ?>
            <style>
                .loader {
                    width: 35px;
                    height: 35px;
                    border: 5px solid #282323;
                    border-bottom-color: transparent;
                    border-radius: 50%;
                    display: inline-block;
                    box-sizing: border-box;
                    animation: rotation 1s linear infinite;
                    margin-left: 50%;
                }

                @keyframes rotation {
                    0% {
                        transform: translateX(-50%) rotate(0deg);
                    }
                    100% {
                        transform: translateX(-50%) rotate(360deg);
                    }
                }
            </style>
        <?php
    });

    add_action('wp_ajax_load_more_posts','load_more_posts');
    add_action('wp_ajax_nopriv_load_more_posts','load_more_posts');
    add_action('wp_ajax_load_categories','load_categories');
    add_action('wp_ajax_nopriv_load_categories','load_categories');

    add_action('wp_ajax_get_taxonomies',function(){

        $args       = array(
            'object_type' => (array) filter_input(INPUT_GET,'post_type',FILTER_SANITIZE_STRING),
            'public'      => true,
            'show_ui'     => true,
        );

        $taxonomies = get_taxonomies( $args, 'object' );

        $response = '';

        foreach ( $taxonomies as $taxonomy ) {
            $response .= sprintf(
                "<option value='%s'>%s</option>",
                $taxonomy->name,
                $taxonomy->label
            );
        }

        die( $response );
    });

    add_action('wp_ajax_load_terms',function(){

        $taxonomy = filter_input(INPUT_GET,'taxonomy',FILTER_SANITIZE_STRING);
        $q        = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);

        wp_send_json_success(get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => true,
            'search'     => $q
        ]));

    });

    add_action('wp_ajax_load_posts',function(){

        $taxonomy     = filter_input(INPUT_GET,'taxonomy',FILTER_SANITIZE_STRING);
        $q            = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
        $post_type    = filter_input(INPUT_GET,'post_type',FILTER_SANITIZE_STRING);


        $posts        = [];

        $args = array(
            'post_type'       => $post_type,
            's'               => $q,
            'posts_per_page'  => -1,
            'tax_query'       => [
                'relation'    => 'OR',
                array(
                    'taxonomy' => $taxonomy,
                    'field'    => 'term_id',
                    'terms'    => (array) $terms
                )
            ]
        );

        $query = new WP_Query( $args );

        if ( $query->have_posts() ) {
            while( $query->have_posts() ) : $query->the_post();
                $posts[] = $query->post;
            endwhile;
        }

        wp_reset_postdata();

        wp_send_json_success( $posts );
    });

    add_action('elementor/widgets/register',function( $registerer ){

        require_once __DIR__ . '/custom-posts-grouping.php';

        $registerer->register( new CustomPostsGroupingByCategories() );
    });


    add_action( 'elementor/controls/register',function( $controls_manager ){
        require_once __DIR__ . '/select-control.php';
        require_once __DIR__ . '/post-select.php';
        $controls_manager->register( new TermSelectControl );
        $controls_manager->register( new PostsSelectControl );
    });

});


function get_posts_by_category( $post_type,$taxonomy,$terms,$offset,$limit,$template_id,$column = 3,$args = array() ){

    $args = wp_parse_args( $args, array(
        'post_type'   =>  $post_type,
        'post_status' => 'publish',
        'tax_query'   => [
            [
                'taxonomy'  => $taxonomy,
                'field'     => 'term_id',
                'terms'     => $terms
            ]
        ],
        'posts_per_page' => -1
    ));

    $query = new WP_Query($args);

    $response = [
        'has_more' => $query->found_posts > $offset + $limit,
        'data'     => null,
        'offset'   => $offset + $limit
    ];

    // Count total posts

    $query = new WP_Query( array_merge($args,[
        'posts_per_page' => $limit,
        'offset'         => $offset
    ]));

    if ( $query->have_posts() ) {
        while( $query->have_posts() ) : $query->the_post();
            $response['data'] .= sprintf(
                "<div class='col-%d cpt-single-post'>%s</div>",
                $column,
                \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $template_id )
            );
        endwhile;
    }

    return $response;
}

function load_categories(){
   $offset             = filter_input(INPUT_GET,'offset',FILTER_VALIDATE_INT);
    $posts_offset       = filter_input(INPUT_GET,'postsOffset',FILTER_VALIDATE_INT);
    $posts_limit        = filter_input(INPUT_GET,'postsLimit',FILTER_VALIDATE_INT);
    $template_id        = filter_input(INPUT_GET,'template_id',FILTER_VALIDATE_INT);
    $init_posts_offset  = filter_input(INPUT_GET,'initPostsOffset',FILTER_VALIDATE_INT);
    $taxonomy           = filter_input(INPUT_GET,'taxonomy',FILTER_SANITIZE_STRING);
    $post_type          = filter_input(INPUT_GET,'post_type',FILTER_SANITIZE_STRING);
    $order              = filter_input(INPUT_GET,'order',FILTER_SANITIZE_STRING);
    $orderby            = filter_input(INPUT_GET,'orderby',FILTER_SANITIZE_STRING);
    $terms_filter       = filter_input(INPUT_GET,'terms_filter',FILTER_SANITIZE_STRING);
    $terms              = $_GET['terms'] ?? array();
    $column             = filter_input(INPUT_GET,'column',FILTER_VALIDATE_INT);

    $args = [
        'taxonomy'        => $taxonomy,
        'hide_empty'      => true,
        "order"           => $order,
        "orderby"         => $orderby,
        "{$terms_filter}" => $terms,
    ];

    $response = [
        'has_more'        => wp_count_terms( $args ) > $offset + 1,
        'offset'          => $offset + 1,
        'data'            => null,
    ];

    $args['offset'] = $offset;
    $args['number'] = 1;

    $terms = get_terms( $args );

    if ( is_wp_error( $terms ) ) {
        //do something on error
    }

    /** *@var WP_Term $term */
    $term = array_shift( $terms );

    if ( ! empty( $term ) ) {
        $posts = get_posts_by_category( $post_type,$taxonomy,$term->term_id,max( 0,$init_posts_offset - $posts_limit ),$posts_limit,$template_id,$column );

        $response['data']        = "<h1 class='cpt-group-heading'>{$term->name}</h1>";
        $response['data']       .= $posts['data'];
        $response['category_id'] = $term->term_id;
    }

    wp_send_json_success($response);
}

function load_more_posts()
{
    $offset      = filter_input(INPUT_GET,'offset',FILTER_VALIDATE_INT);
    $limit       = filter_input(INPUT_GET,'limit',FILTER_VALIDATE_INT);
    $term        = filter_input(INPUT_GET,'term',FILTER_VALIDATE_INT);
    $template_id = filter_input(INPUT_GET,'template_id',FILTER_VALIDATE_INT);
    $post_type   = filter_input(INPUT_GET,'post_type',FILTER_SANITIZE_STRING);
    $taxonomy    = filter_input(INPUT_GET,'taxonomy',FILTER_SANITIZE_STRING);
    $post_filter = filter_input(INPUT_GET,'post_filter',FILTER_SANITIZE_STRING);
    $posts       = $_GET['posts'] ?? [];
    $column      = filter_input(INPUT_GET,'column',FILTER_VALIDATE_INT);

    $response    = get_posts_by_category( $post_type,$taxonomy,$term,$offset,$limit,$template_id,$column,array(
        "{$post_filter}" => $posts
    ));

    wp_send_json_success($response);
}