<?php


use Elementor\Control_Select2;

if (!defined('ABSPATH')) {
    exit;
}

class PostsSelectControl extends Control_Select2
{

    const SELECT2 = 'posts-select';


    public function get_type()
    {
        return self::SELECT2;
    }

}
