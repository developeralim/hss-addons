<?php
    namespace HerSuitespotAddons\Extra;

    class Admin {

        public function __construct()
        {
            // Custom brand image meta box
            add_action('add_meta_boxes', [$this,'brand_image_meta_box']);
            add_action('add_meta_boxes', [$this,'due_date_meta_box']);
            add_action('add_meta_boxes', [$this,'external_link_meta_box']);

            add_action('admin_enqueue_scripts',[$this,'admin_scripts']);
            add_action('save_post', [$this,'save_meta_box_data']);

            add_filter('manage_resource_posts_columns',[$this,'add_featured_column']);
            add_action('manage_resource_posts_custom_column',[$this,'render_featured_content'],  10, 2 );
            add_filter('manage_funding_posts_columns',[$this,'add_featured_column']);
            add_action('manage_funding_posts_custom_column',[$this,'render_featured_content'],  10, 2 );
        }

        public function admin_scripts()
        {
            wp_enqueue_script(
                'hersuitespot-addon-admin',
                HERSUITESPOT_PLUGIN_URL . 'assets/admin/admin.js',
                ['jquery'],
                HERSUITESPOT_PLUGIN_VERSION
            );

            wp_enqueue_style(
                'hersuitespot-addon-admin',
                HERSUITESPOT_PLUGIN_URL . 'assets/admin/admin.css',
                [],
                HERSUITESPOT_PLUGIN_VERSION
            );
        }

        public function brand_image_meta_box() {
            add_meta_box(
                'brand_image_meta_box',
                'Brand Logo (Best fit 75px by 75px)',
                [$this,'meta_box_render'],
                ['resource'],
                'side',
                'default'
            );
        }

        public function meta_box_render( $post )
        {
            $image_url = get_post_meta($post->ID, '_brand_image', true);

            wp_nonce_field(basename(__FILE__), 'hersuitespot_metabox_nonce');

            ?>
                <img src="<?php echo esc_url($image_url); ?>" alt="No Image Selected">
                <input type="hidden" name="brand_image" id="brand_image" class="meta-image" value="<?php echo esc_attr($image_url); ?>">
                <input type="button" class="button brand_upload_btn" value="Choose or Upload Image">
            <?php
        }

        public function due_date_meta_box()
        {
            add_meta_box(
                'due_date_meta_box',
                'Select due date',
                [$this,'due_date_render'],
                ['funding'],
                'side',
                'default'
            );
        }

        public function due_date_render(  $post  )
        {

            $due_date = get_post_meta(  $post->ID,'_due_date',true );

            list( $date,$time ) = array_pad(explode(' ',$due_date),2,'');

            wp_nonce_field(basename(__FILE__), 'hersuitespot_metabox_nonce');

            ?>
                <div class="date">
                    <input type="date" name="due_date" class="form__input" value="<?php echo $date; ?>">
                </div>
                <div class="time">
                    <input type="time" name="due_time" class="form__input" value="<?php echo $time; ?>">
                </div>
            <?php
        }

        public function external_link_meta_box()
        {
            add_meta_box(
                'external_link_meta_box',
                'External link',
                [$this,'external_link_render'],
                ['funding','resource'],
                'side',
                'default'
            );
        }

        public function external_link_render(  $post  )
        {

            $external_link = get_post_meta(  $post->ID,'_external_link',true );
            $btn_text      = get_post_meta( $post->ID,'_cta_btn_text',true );

            wp_nonce_field(basename(__FILE__), 'hersuitespot_metabox_nonce');

            ?>
                <label for="ext__link"><?php echo esc_attr('Link'); ?></label>
                <input type="text" name="external_link" class="form__input w-100" value="<?php echo $external_link; ?>" placeholder="<?php echo esc_attr('e.g https://example.com/external') ?>" required>
                <br>
                <label for="ext__link" style="margin-top:5px;"><?php echo esc_attr('Button Text'); ?></label>
                <input type="text" name="btn_text" class="form__input w-100" value="<?php echo $btn_text; ?>" required>
            <?php
        }

        public function save_meta_box_data( $post_id )
        {
            if (!isset($_POST['hersuitespot_metabox_nonce']) || !wp_verify_nonce($_POST['hersuitespot_metabox_nonce'], basename(__FILE__))) {
                return $post_id;
            }

            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }

            if ( isset($_POST['brand_image']) ) {
                update_post_meta($post_id, '_brand_image', esc_url($_POST['brand_image']));
            }

            if ( isset( $_POST['due_date'],$_POST['due_time']) ) {

                $due_date = ! ( $_POST['due_date'] == ''  || $_POST['due_time'] == '' )
                            ?  sprintf("%s %s",$_POST['due_date'],$_POST['due_time'])
                            : 'rolling';

                update_post_meta($post_id,'_due_date',$due_date);
            }

            if ( isset($_POST['external_link']) ) {
                update_post_meta($post_id, '_external_link', esc_url($_POST['external_link']));
            }

            if ( isset($_POST['btn_text']) ) {
                update_post_meta($post_id, '_cta_btn_text', esc_attr($_POST['btn_text']));
            }
        }

        public function add_featured_column( $columns )
        {
            $beforeLast = array_slice( $columns,0,count( $columns ) - 1 );
            $last       = array_slice( $columns,-1 );

            return  array_merge( $beforeLast,['featured' => esc_html('Featured')],$last );
        }

        function render_featured_content ( $column_id, $post_id ) {
            if ( $column_id == 'featured' ) {

                $is_featured = get_post_meta( $post_id,'_featured',true );

                printf('
                    <a data-id="%d" data-status="%d" title="%s" href="#" data-nonce="%s" class="make__featured">
                        <span class="dashicons %s"></span>
                    </a>',
                    $post_id,
                    ! $is_featured,
                    true == $is_featured ? 'Remove from featured' : 'Mark as featured',
                    wp_create_nonce('hersuitespot__post__featured'),
                    true == $is_featured ? 'dashicons-star-filled' : 'dashicons-star-empty',
                );
            }
        }
    }
