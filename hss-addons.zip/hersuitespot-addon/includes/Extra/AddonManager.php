<?php
    namespace HerSuitespotAddons\Extra;

    class AddonManager {

        /**
         * Addons Container
         *
         * @var array
         */
        public array $addons = [];

        /**
         * Widget Register hook
         *
         * @var string
         */
        public string $register_hook;

        public function __construct( array $addons )
        {
            $this->addons = $addons;

            if ( defined( 'ELEMENTOR_VERSION' ) ) {
                if ( version_compare( ELEMENTOR_VERSION, '3.5.0', '>=' ) ) {
                    add_action( 'elementor/widgets/register', array( $this,'register_addons' ));
                }else {
                    add_action( 'elementor/widgets/widgets_registered',array( $this,'register_addons' ));
                }

                add_action('admin_enqueue_scripts',array($this,'register_addons_dependency'));
                add_action('wp_enqueue_scripts',array($this,'register_addons_dependency'));
            }
        }

        /**
         * Register addons
         *
         * @param \Elementor\Widgets_Manager $widegt_manager
         * @return void
         */
        public function register_addons( $widegt_manager )
        {
            foreach( $this->addons as $addon ) {

                $addon = wp_parse_args( $addon,$this->default_addon_args() );

                extract( $addon );

                $widegt_manager->register(new $widget());
            }
        }

        public function register_addons_dependency()
        {
            $dependencies = array_column( $this->addons,'dependency' );

            foreach( $dependencies as $dependency ) {
                $this->enqueue_styles( (array) $dependency['styles'] );
                $this->enqueue_scripts( ( array ) $dependency['scripts'] );
            }

            return true;
        }

        private function enqueue_styles( $styles = [] )
        {
            foreach( $styles as $handler => $url ) {
                wp_register_style( $handler,$url,[],HERSUITESPOT_PLUGIN_VERSION );
            }

            return true;
        }

        private function enqueue_scripts( $scripts = [] )
        {
            foreach( $scripts as $handler => $url ) {
                wp_register_script( $handler,$url,['jquery'],HERSUITESPOT_PLUGIN_VERSION );
            }

            return true;
        }

        private function default_addon_args()
        {
            return [
                'class'       => '',
                'dependency'  => [
                    'css' => [],
                    'js'  => []
                ]
            ];
        }
    }
