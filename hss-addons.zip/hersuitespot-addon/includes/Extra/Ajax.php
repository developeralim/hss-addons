<?php
    namespace HerSuitespotAddons\Extra;

    class Ajax {

        public const AJAX_NONCE = 'hersuitespot-addon-js';

        public function __construct()
        {
            add_action('wp_ajax_filter_custom_post_type_data',array($this,'filter_custom_post_type_data'));
            add_action('wp_ajax_nopriv_filter_custom_post_type_data',array($this,'filter_custom_post_type_data'));
            add_action('wp_ajax_featured_action',array($this,'featured_action'));
        }

        public function filter_custom_post_type_data()
        {
            $nonce = $_POST['nonce'];

            if ( !wp_verify_nonce( $nonce, self::AJAX_NONCE ) ) {
                return; // Get out of here, the nonce is rotten!
            }

            $tax_query    = [];

            if ( ! empty( $_POST['taxonomies'] ) ) {
                foreach( $_POST['taxonomies'] as $taxonomy => $terms  ) {
                    $tax_query[] = [
                        'taxonomy' => $taxonomy,
                        'field'    => 'id',
                        'terms'    => $terms,
                        'operator' => 'IN'
                    ];
                }
            }

            ['posts' => $posts,'total_pages' => $total_pages] = Helper::instance()->get_posts([
                'post_type'        => $_POST['post_type'],
                'posts_per_page'   => $_POST['limit'],
                'paged'            => $_POST['page'],
                'order'            => $_POST['order'],
                'tax_query'        => $tax_query,
                'terms_order'      => $_POST['terms_order'] ?? []
            ]);

            $paginations = Helper::instance()->make_pagination(
                $total_pages,
                $_POST['page']
            );

            $post_items  = Helper::instance()->build_post_template(
                $posts,
                $_POST['template'] ?? 'template_1'
            );

            wp_send_json_success([
                'post_items'  => $post_items,
                'paginations' => $paginations,
                'total_pages' => $total_pages
            ]);
        }

        public function featured_action()
        {

            if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce($_POST['nonce'],'hersuitespot__post__featured') ) {
                wp_send_json_error([
                    'message' => esc_attr('Unauthorized')
                ]);
            }

            $post_id = $_POST['id'];

            update_post_meta( $post_id,'_featured',$_POST['status'] );

        }
    }
