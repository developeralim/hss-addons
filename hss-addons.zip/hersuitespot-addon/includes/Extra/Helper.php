<?php
    namespace HerSuitespotAddons\Extra;

    use DateTime;
    use WP_Post;
    use WP_Term;

    class Helper {

        private static ?self $instance = null;

        public function make_pagination( $total_pages = 1,$current_page = 1,$start = 1 )
        {
            if ( $total_pages <= 1 ) {
                return;
            }

            ob_start();

            ?>
                <ul>
                    <li>
                        <a href="#" class="page" data-page="prev"><span class="dashicons dashicons-arrow-left-alt2"></span></a>
                    </li>
                    <?php
                        while( $start <= $total_pages ) {
                            printf(
                                '<li><a href="#" class="page %1$s" data-page="%2$d">%2$d</a></li>',
                                $start == $current_page ? 'active' : '',
                                $start
                            );
                            $start++;
                        }
                    ?>
                    <li>
                        <a href="#" class="page" data-page="next"><span class="dashicons dashicons-arrow-right-alt2"></span></a>
                    </li>
                </ul>
            <?php

            return ob_get_clean();
        }

        public function get_posts( $args )
        {
            $default_args = [
                'post_type'      => 'post',
                'posts_per_page' => -1,
                'post_status'    => 'publish',
                'paged'          => 1,
                'tax_query'      => [],
                'order'          => 'desc',
                'meta_query'     => []
            ];

            $args = wp_parse_args( $args,$default_args );


            if ( in_array( $args['post_type'],['funding'] ) ) {
                // Filter post by due date
                $args['meta_query'][] = [
                    [
                        'key'      => '_due_date',
                        'value'    => (new DateTime('now',wp_timezone()))->format('Y-m-d H:i'),
                        'type'     => 'DATETIME',
                        'compare' => '>='
                    ],
                    [
                        'key'      => '_due_date',
                        'value'    => 'rolling',
                        'compare'  => '='
                    ],
                    'relation'   => 'OR'
                ];
            }

            $terms = array_flip(
                $args['terms_order'] ?? []
            );
          
            $posts = array_map( fn() => [] , $terms );

            $query = new \WP_Query( $args );

            $total_pages  = $query->max_num_pages;

            if ( $query->have_posts() ) {

                while( $query->have_posts() ) {
                    $query->the_post();

                    $post = $query->post;

                    $terms_array = get_the_terms($post, $args['post_type'] . '_category');

                    if ( ! is_array($terms_array) ) {
                        $terms_array = [];
                    }

                    $term = array_shift( $terms_array );

                    if ( $term instanceof WP_Term ) {
                        $key = $term->name;
                    } else {
                        $key = '';
                    }

                    $posts[$key][] = $post;
                }

                wp_reset_postdata();
            }
            
            return compact('posts','total_pages');
        }

        public function build_post_template( array $posts = [],$template = 'template_1',$featured = false )
        {
            ob_start();

            foreach( $posts as $category => $post_collection ) :
                if ( ! $featured ) {
                    ?>
                        <div class="cm__list__category"><?php echo esc_html( $category ); ?></div>
                    <?php
                }
                foreach( $post_collection as $post ) :
                    /**
                     * @var WP_Post $post
                     */
                    ?>
                        <div class="cm__list__item" onclick="window.open('<?php echo $this->get_permalink( $post->ID,$post->post_type ); ?>','_blank');" data-title="<?php esc_html_e( get_the_title( $post ),HERSUITESPOT_TEXTDOMAIN ) ?>" data-taxonomy="<?php $this->terms_string($post); ?>" data-excerpt="<?php esc_html_e( get_the_excerpt( $post ),HERSUITESPOT_TEXTDOMAIN ) ?>">
                            <picture>
                                <?php echo get_the_post_thumbnail( $post,'full' ) ?>
                            </picture>

                            <div class="cm__info <?php echo $template; ?>">

                                <?php if ( $template == 'template_1' && ( $url = get_post_meta( $post->ID,'_brand_image',true ) ) ) :  ?>
                                    <img src="<?php echo esc_url( $url ); ?>">
                                <?php endif; ?>

                                <div class="cm__description">
                                    <h4><?php esc_html_e( get_the_title( $post ),HERSUITESPOT_TEXTDOMAIN ) ?></h4>
                                    <p><?php esc_html_e( get_the_excerpt( $post ),HERSUITESPOT_TEXTDOMAIN ) ?></p>
                                </div>

                                <?php if ( $template == 'template_2' ): ?>
                                    <div class="due__date">
                                        <div class="left">
                                            <a target="_blank" href="<?php echo $this->get_permalink( $post->ID,$post->post_type ) ?>" class="cta__btn"><?php echo esc_html( get_post_meta($post->ID,'_cta_btn_text',true) ); ?></a>
                                        </div>
                                        <div class="right">

                                            <?php  if ( ( $due = get_post_meta( $post->ID,'_due_date',true ) ) !== 'rolling' ) : ?>
                                                <span class="text_muted"><?php echo esc_attr('Due date : '); ?></span>
                                                <span class="text_bold">
                                                    <?php echo mysql2date( get_option('date_format','m/d/Y'), $due ); ?>
                                                </span>
                                            <?php else : ?>
                                                <span class="text_bold"><?php echo esc_html('Rolling...'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php
                endforeach;
            endforeach;

            return ob_get_clean();
        }

        private function get_permalink( $post_id,$post_type )
        {
            $permalink = get_post_meta($post_id,'_external_link',true);

            if ( in_array( $post_type,['resource','funding'] ) || $permalink == null || empty( $permalink ) || $permalink == '' ) {
                $permalink = get_the_permalink( $post_id );
            }

            return $permalink;
        }

        private function terms_string($post,$seperator = ',')
        {
            $taxonomy_string = '';

            foreach( get_the_taxonomies( $post ) as $slug => $name ) {
                $name              = substr( $name,strpos( $name,':' ) + 1 );
                $taxonomy_string  .= str_replace(' and ',',',$name);
            }

            $taxonomy_string = strip_tags(
                str_replace('.',',',$taxonomy_string)
            );

            echo rtrim( $taxonomy_string,',' );
        }

        public function get_post_types()
        {
            $return = [];

            $post_types = get_post_types([
                'public'    => true,
            ],'objects');

            foreach( $post_types as $post_type ) {
                $return[$post_type->name] = $post_type->label;
            }

            return $return;
        }

        public function get_taxonomies()
        {
            $return = [];

            $taxonomies = get_taxonomies();

            foreach( $taxonomies as $taxonomy ) {
                $taxonomy = get_taxonomy( $taxonomy );

                $return[ $taxonomy->name ] = $taxonomy->label;

            }

            return $return;
        }

        public function get_terms( $taxonomy )
        {
            $terms = get_terms([
                'taxonomy'  => $taxonomy,
                'orderby'   => 'term_id',
                'order'     => 'ASC'
            ]);

            $toReturn = [];

            foreach( $terms as $term ) {
                $toReturn["$term->name"] = esc_html( $term->name );
            }

            return $toReturn;
        }

        public static function instance()
        {
            if ( ! self::$instance ) {
                self::$instance = new self;
            }

            return self::$instance;
        }
    }
