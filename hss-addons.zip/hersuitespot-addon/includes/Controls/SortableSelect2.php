<?php

namespace HerSuitespotAddons\Controls;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

class SortableSelect2 extends \Elementor\Base_Data_Control {

	/**
	 * Get currency control type.
	 *
	 * Retrieve the control type, in this case `currency`.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Control type.
	 */
	public function get_type() {
		return '__SORTABLE_SELECT2__';
	}

	/**
	 * Get currency control default settings.
	 *
	 * Retrieve the default settings of the currency control. Used to return
	 * the default settings while initializing the currency control.
	 *
	 * @since 1.0.0
	 * @access protected
	 * @return array Currency control default settings.
	 */
	protected function get_default_settings() {
		return [

		];
	}

	/**
	 * Get currency control default value.
	 *
	 * Retrieve the default value of the currency control. Used to return the
	 * default value while initializing the control.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Currency control default value.
	 */
	public function get_default_value() {
		return '';
	}

    public function enqueue()
    {
        wp_enqueue_script('jquery-elementor-select2');
        wp_register_script('hss-control-script',HERSUITESPOT_PLUGIN_URL . 'assets/controls/scripts.js',['jquery'],HERSUITESPOT_PLUGIN_VERSION);
        wp_register_style('hss-control-style',HERSUITESPOT_PLUGIN_URL . 'assets/controls/style.css',[],HERSUITESPOT_PLUGIN_VERSION);
        wp_enqueue_script('hss-control-script');
        wp_enqueue_style('hss-control-style');
    }

	/**
	 * Render currency control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function content_template() {
		    $control_uid = $this->get_control_uid();
		?>

		<div class="elementor-control-field">

			<# if ( data.label ) {#>
			<label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<# } #>

			<div class="elementor-control-input-wrapper">
				<select placeholder="Select Order" style="width:100px;" class="hss__select2__sortable" multiple="multiple" id="<?php echo $control_uid; ?>" data-setting="{{ data.name }}">
					<# _.each( data.options, function( key, value ) { #>
					<option value="{{ key }}">{{{ value }}}</option>
					<# } ); #>
				</select>
			</div>

		</div>

		<# if ( data.description ) { #>
		<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}

}
