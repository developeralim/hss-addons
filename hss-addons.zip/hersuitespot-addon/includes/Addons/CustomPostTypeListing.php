<?php

namespace HerSuitespotAddons\Addons;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Plugin;
use \Elementor\Widget_Base;
use HerSuitespotAddons\Extra\Helper;
use WP_Term;

class CustomPostTypeListing extends Widget_Base
{
    public function get_name()
    {
        return 'custom-post-type-listing';
    }

    public function get_title()
    {
        return esc_html__('HerSuite Custom Post Listing', HERSUITESPOT_TEXTDOMAIN);
    }

    public function get_icon()
    {
        return 'eicon-posts-masonry';
    }

    public function get_categories()
    {
        return ['HerSuitespot'];
    }

    public function get_keywords()
    {
        return [
            'post listing',
            'resource listing',
            'custom post type listing',
            'listing with filter'
        ];
    }

    public function get_style_depends()
    {
        return [
            'font-awesome',
            'font-awesome-5-all',
            'font-awesome-4-shim',
            'dashicons',
            'owl-carousel',
            'owl-carousel-theme',
            'custom-post-type-css',
        ];
    }

    public function get_script_depends()
    {
        return ['custom-post-type-js', 'owl-carousel',];
    }

    public function get_custom_help_url()
    {
        return 'https://github.com/developeralim/herSuitespot-Addon';
    }

    protected function register_controls()
    {
       $this->content_tab_controls();
    }

    private function content_tab_controls()
    {
        $this->start_controls_section('content_section',[
            'label' => esc_html__( 'Content', HERSUITESPOT_TEXTDOMAIN ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control(
			'post_type',
			[
				'label' => esc_html__( 'Select post type', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => Helper::instance()->get_post_types(),
                'default' => 'post'
			]
		);

        $this->add_control(
			'template',
			[
				'label' => esc_html__( 'Select post template', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
                    'template_1' => esc_html__('Template 1',HERSUITESPOT_TEXTDOMAIN),
                    'template_2' => esc_html__('Template 2',HERSUITESPOT_TEXTDOMAIN),
                    'template_3' => esc_html__('Template 3',HERSUITESPOT_TEXTDOMAIN),
                    'template_4' => esc_html__('Template 4',HERSUITESPOT_TEXTDOMAIN),
                ],
                'default' => 'template_1'
			]
		);

        $this->add_control(
			'featured_area',
			[
				'label' => esc_html__( 'Enable Featured Section', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Disable',HERSUITESPOT_TEXTDOMAIN ),
				'label_on' => esc_html__( 'Enable',HERSUITESPOT_TEXTDOMAIN ),
				'return_value' => 'enable',
                'default' => 'disable'
			]
		);

        $this->add_control(
			'featured_title',
			[
				'label' => esc_html__( 'Featured title', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Featured area',HERSUITESPOT_TEXTDOMAIN ),
				'placeholder' => esc_html__( 'Featured title', HERSUITESPOT_TEXTDOMAIN ),
                'condition' => [
                    'featured_area' => 'enable'
                ]
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .section__title',
			]
		);

        $this->add_control(
			'carousel_dot',
			[
				'label'         => esc_html__( 'Dots', HERSUITESPOT_TEXTDOMAIN ),
				'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'true'  => esc_html__('True',HERSUITESPOT_TEXTDOMAIN),
                    'false' => esc_html__('False',HERSUITESPOT_TEXTDOMAIN),
                ],
                'default'       => 'false',
                'condition'     => [
                    'featured_area' => 'enable'
                ]
			]
		);

        $this->add_control(
			'carousel_loop',
			[
				'label' => esc_html__( 'Loop', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
                'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'true'  => esc_html__('True',HERSUITESPOT_TEXTDOMAIN),
                    'false' => esc_html__('False',HERSUITESPOT_TEXTDOMAIN),
                ],
                'default'       => 'false',
                'condition'     => [
                    'featured_area' => 'enable'
                ]
			]
		);


        $this->add_control(
			'carousel_nav',
			[
				'label' => esc_html__( 'Nav', HERSUITESPOT_TEXTDOMAIN ),
				'type'          => \Elementor\Controls_Manager::SELECT,
                'options'       => [
                    'true'  => esc_html__('True',HERSUITESPOT_TEXTDOMAIN),
                    'false' => esc_html__('False',HERSUITESPOT_TEXTDOMAIN),
                ],
                'default'       => 'false',
                'condition'     => [
                    'featured_area' => 'enable'
                ]
			]
		);

        $this->add_control(
			'carousel_margin',
			[
				'label' => esc_html__( 'Margin', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 10,
                'condition' => [
                    'featured_area' => 'enable'
                ]
			]
		);

        $this->end_controls_section();

        // Filtering controls
        $this->start_controls_section('filter_section',[
            'label' => esc_html__( 'Filter', HERSUITESPOT_TEXTDOMAIN ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control(
			'search',
			[
				'label' => esc_html__( 'Enable search', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Enable',HERSUITESPOT_TEXTDOMAIN),
				'label_off' => esc_html__( 'Disable', HERSUITESPOT_TEXTDOMAIN ),
				'return_value' => 'enable',
				'default' => 'disable',
			]
		);

        $this->add_control(
			'search_placeholder',
			[
				'label' => esc_html__( 'Placeholder', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Placeholder',HERSUITESPOT_TEXTDOMAIN ),
				'placeholder' => esc_html__( 'Search box placeholder', HERSUITESPOT_TEXTDOMAIN ),
                'condition' => [
                    'search' => 'enable'
                ]
			]
		);

        $this->add_control(
			'search_icon',
			[
				'label' => esc_html__( 'Search Icon', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-search',
					'library' => 'fa-solid',
				],
                'condition' => [
                    'search' => 'enable'
                ]
			]
		);


        $this->add_control(
			'filter_by_order',
			[
				'label'         => esc_html__( 'Filter by order', HERSUITESPOT_TEXTDOMAIN ),
				'type'          => \Elementor\Controls_Manager::SWITCHER,
				'label_on'      => esc_html__( 'Enable',HERSUITESPOT_TEXTDOMAIN),
				'label_off'     => esc_html__( 'Disable', HERSUITESPOT_TEXTDOMAIN ),
				'return_value'  => 'enable',
				'default'       => 'disable',
			]
		);

        $this->add_control(
			'order',
			[
                'label' => esc_html__( 'Order', HERSUITESPOT_TEXTDOMAIN ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'solid',
                'options' => [
                    'desc' => esc_html__('DESC',HERSUITESPOT_TEXTDOMAIN),
                    'asc'  => esc_html__('ASC',HERSUITESPOT_TEXTDOMAIN),
                ],
                'default' => 'desc',
                'condition' => [
                    'filter_by_order' => 'enable',
                ],
			]
		);

        // Filter by limit
        $this->add_control(
			'limit',
			[
				'label'         => esc_html__( 'Maximum items to show', HERSUITESPOT_TEXTDOMAIN ),
				'type'          => \Elementor\Controls_Manager::NUMBER,
				'min'           => -1,
				'step'          => 10,
				'default'       => 40,
			]
		);

        $this->add_control(
            'filter_by_limit',
            [
                'label'         => esc_html__( 'Filter by limit', HERSUITESPOT_TEXTDOMAIN ),
                'type'          => \Elementor\Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'Enable',HERSUITESPOT_TEXTDOMAIN),
                'label_off'     => esc_html__( 'Disable', HERSUITESPOT_TEXTDOMAIN ),
                'return_value'  => 'enable',
                'default'       => 'disable',
            ]
        );

        $this->add_control(
			'limit_values',
			[
				'label' => esc_html__( 'Limits', HERSUITESPOT_TEXTDOMAIN ),
				'type' => \Elementor\Controls_Manager::REPEATER,
                'label_block' => false,
				'fields' => [
					[
						'name'      => 'value',
						'label'     => esc_html__( 'Value', HERSUITESPOT_TEXTDOMAIN ),
                        'type'      => \Elementor\Controls_Manager::NUMBER,
                        'min'       => 1,
					],
				],
                'title_field' => esc_html__( 'Option', HERSUITESPOT_TEXTDOMAIN ),
                'condition' => [
                    'filter_by_limit' => 'enable',
                ],
			]
		);

        // Filter by taxonomy
        $this->add_control(
            'filter_by_taxonomy',
            [
                'label'         => esc_html__( 'Filter by taxonomy',HERSUITESPOT_TEXTDOMAIN  ),
                'type'          => \Elementor\Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'Enable',HERSUITESPOT_TEXTDOMAIN),
                'label_off'     => esc_html__( 'Disable', HERSUITESPOT_TEXTDOMAIN ),
                'return_value'  => 'enable',
                'default'       => 'disable',
            ]
        );

        $this->add_control(
			'taxonomies',
			[
				'label' => esc_html__('Select Taxonomy', HERSUITESPOT_TEXTDOMAIN),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => false,
				'multiple' => true,
				'options' => Helper::instance()->get_taxonomies(),
				'default' => [],
                'condition' => [
                    'filter_by_taxonomy' => 'enable',
                ],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section('style_section',[
            'label' => esc_html__( 'Style', HERSUITESPOT_TEXTDOMAIN ),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        ]);


        $this->add_responsive_control(
			'items_in_row',
			[
				'label' => esc_html__('Items width', HERSUITESPOT_TEXTDOMAIN),
				'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
                'size_units' => ['px','%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .cm__list__item'   => 'width: {{SIZE}}{{UNIT}};',
                ],
			]
		);

        $this->add_responsive_control(
			'item_height',
			[
                'label'      => __('Item height', HERSUITESPOT_TEXTDOMAIN),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 20,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 10,
					'unit' => 'px',
				],
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .cm__list__item'   => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
		);

        $this->add_responsive_control(
			'items_in_featured',
			[
				'label' => esc_html__('Items to show in featured area', HERSUITESPOT_TEXTDOMAIN),
				'type' => \Elementor\Controls_Manager::SELECT,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'options' => [
                    '1' => 1,
                    '2' => 2,
                    '3' => 3,
                    '4' => 4,
                    '5' => 5,
                    '6' => 6,
                    '7' => 7,
                    '8' => 8,
                    '9' => 9,
                    '10' => 10,
                    '11' => 11,
                    '12' => 12,
                ],
                'desktop_default'  => '4',
                'tablet_default'   => '3',
                'mobile_default'   => '2',
                'default'          => '4'
			]
		);


        $this->end_controls_section();

        // Ordering section
        $this->start_controls_section('order_section',[
            'label' => esc_html__( 'Order Fundiung', HERSUITESPOT_TEXTDOMAIN ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);


        $this->add_control(
			'terms_ordering',
			[
				'label'         => esc_html__( 'Enable Category Ordering', HERSUITESPOT_TEXTDOMAIN ),
				'type'          => \Elementor\Controls_Manager::SWITCHER,
				'label_off'     => esc_html__( 'Disable',HERSUITESPOT_TEXTDOMAIN ),
				'label_on'      => esc_html__( 'Enable',HERSUITESPOT_TEXTDOMAIN ),
				'return_value'  => 'enable',
                'default'       => 'disable'
			]
		);

        $this->add_control(
			'terms_order',
			[
                'label'     => esc_html__( 'Category', HERSUITESPOT_TEXTDOMAIN ),
                'type'      => '__SORTABLE_SELECT2__',
                'default'   => 'solid',
                'multiple'  => true,
                'options'   => Helper::instance()->get_terms(
                    "funding_category"
                ),
                'condition' => [
                    'terms_ordering' => 'enable',
                ],
			]
		);

        $this->end_controls_section();
    }

    protected function render()
    {
        
        $settings = $this->get_settings_for_display();

        $editor_mode = Plugin::$instance->editor->is_edit_mode();

        $args = [
            'post_type'              => $settings['post_type'],
            'posts_per_page'         => $settings['limit'],
        ];

        $args['terms_order'] =  $settings['terms_ordering'] == 'enable'
                                ? $settings['terms_order']
                                : [];

        $posts = Helper::instance()->get_posts( $args );

        if ( empty( $posts['posts'] ) ) {
            return;
        }

        $this->add_render_attribute('preloader','style','display:none;');
        $this->add_render_attribute('preloader','id','preloader');
        $this->add_render_attribute('cm_post_type_listing','class','cm__post__listing');

        wp_localize_script('custom-post-type-js','filterOptions',[
            'order'         => $this->get_settings_for_display('order'),
            'limit'         => $this->get_settings_for_display('limit'),
            'template'      => $this->get_settings_for_display('template'),
            'post_type'     => $this->get_settings_for_display('post_type'),
            'pages'         => $posts['total_pages'],
            'page'          => 1,
            'taxonomies'    => array_map( fn() => [],array_flip( $settings['taxonomies'] ?? [] ) ),
            'terms_order'   => $settings['funding_category'] ?? []
        ]);

        ?>
            <div <?php echo $this->get_render_attribute_string('cm_post_type_listing'); ?>>

                <div <?php echo $this->get_render_attribute_string('preloader'); ?>>
                    <div class="lds-ellipsis">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>

                <div class="top__filter">

                    <?php if( $settings['search'] == 'enable' ) : ?>
                        <div class="search">
                            <span class="<?php echo implode(' ',$settings['search_icon']); ?>"></span>
                            <input type="text" class="form__input" id="cp__search" placeholder="<?php echo $settings['search_placeholder']; ?>">
                        </div>
                    <?php endif; ?>

                    <div class="filter">
                        <?php if ( $settings['filter_by_order'] == 'enable' ) :?>
                            <div class="filter__order">
                                <select class="form__select" data-type="order" name="order">
                                    <option <?php $settings['order'] == 'desc' ? print('selected') : ''; ?> value="desc"><?php echo esc_attr('Newest'); ?></option>
                                    <option <?php $settings['order'] == 'asc' ? print('selected') : ''; ?> value="asc"><?php echo esc_attr('Oldest'); ?></option>
                                </select>
                            </div>
                        <?php endif; ?>

                        <?php if ( $settings['filter_by_limit'] == 'enable' ) :?>
                            <div class="filter__limit">
                                <select class="form__select" data-type="limit" name="limit">
                                    <option value="-1">all</option>
                                    <?php
                                        foreach( $settings['limit_values'] as $limit ) {
                                            printf('<option value="%1$d">%1$d</option>',$limit['value']);
                                        }
                                    ?>
                                </select>
                            </div>
                        <?php endif; ?>


                        <?php if ( $settings['filter_by_taxonomy'] == 'enable' ) :?>
                            <div class="filter__taxonomy">
                                <?php

                                    $taxonomyMarkup = '';

                                    foreach( $settings['taxonomies'] as $taxonomy ) {

                                        $taxonomy = get_taxonomy( $taxonomy );

                                        $terms = get_terms([
                                            'taxonomy' => $taxonomy->name
                                        ]);

                                        if ( count( $terms ) == 0 ) {
                                            continue;
                                        }

                                        $termMarkup = '';

                                        foreach( $terms as $term ) {
                                            /**
                                             * @var WP_Term $term
                                             */

                                            $termMarkup .= sprintf('
                                                <label for="%1$s" style="font-size:13px;">
                                                    <input type="checkbox" class="form__check" id="%1$s" name="%2$s" value="%3$d" data-type="taxonomies"> <span>%4$s</span>
                                                </label>',
                                                $term->slug,
                                                $taxonomy->name,
                                                $term->term_id,
                                                $term->name
                                            );
                                        }

                                        $taxonomyMarkup .= sprintf(
                                            '<div class="txonomy__dropdown form__select">
                                                <span style="text-transform:capitalize;" >%1$s</span>
                                                <div class="dropdown__option">
                                                    %2$s
                                                </div>
                                            </div>',

                                            esc_attr( $taxonomy->label ),
                                            $termMarkup
                                        );
                                    }

                                    echo $taxonomyMarkup;
                                ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="content__area">

                    <?php $settings['featured_area'] == 'enable' &&  $this->render_featured_items(); ?>

                    <div class="general__area">
                        <?php
                            if ( $editor_mode ) {
                                echo Helper::instance()->build_post_template(
                                    $posts['posts'],
                                    $settings['template'],
                                );
                            }
                        ?>
                    </div>
                </div>

                <div class="pagination__area">
                    <?php
                        if ( $editor_mode ) {
                            echo Helper::instance()->make_pagination( $posts['total_pages'] );
                        }
                    ?>
                </div>
            </div>
        <?php
    }

    private function render_featured_items()
    {


        $template  = $this->get_settings_for_display('template');

        ['posts' => $posts] = Helper::instance()->get_posts([
            'post_type'  => $this->get_settings_for_display('post_type'),
            'meta_query' => [
                'relation' => 'AND',
                array(
                    'key'     => '_featured',
                    'value'   => '1',
                    'compare' => '='
                ),
            ]
        ]);

        if ( empty( $posts ) ) {
            return;
        }

        ?>
            <div class="featured__area">
                <h2 class="section__title"><?php echo $this->get_settings_for_display('featured_title'); ?></h2>
                <div class="cm__carousel_wraper owl-carousel owl-theme">
                    <?php
                        echo Helper::instance()->build_post_template(
                            $posts,
                            $template,
                            true
                        );
                    ?>
                </div>
            </div>
        <?php

        add_action('wp_print_footer_scripts',function(){
            ?>
                <script>
                    jQuery(document).ready(function(){
                        jQuery('.cm__carousel_wraper').owlCarousel({
                            dots    : <?php echo $this->get_settings_for_display('carousel_dot'); ?>,
                            nav     : <?php echo $this->get_settings_for_display('carousel_nav'); ?>,
                            loop    : <?php echo $this->get_settings_for_display('carousel_loop'); ?>,
                            margin  : <?php echo $this->get_settings_for_display('carousel_margin'); ?>,
                            responsive: {
                                0:{
                                    items:1,
                                },
                                576:{
                                    items: <?php echo $this->get_settings_for_display('items_in_featured_mobile') ?? 2; ?>,
                                },
                                768:{
                                    items: <?php echo $this->get_settings_for_display('items_in_featured_tablet') ?? 3; ?>,
                                },
                                992:{
                                    items: <?php echo $this->get_settings_for_display('items_in_featured') ?? 4; ?>,
                                }
                            }
                        });
                    });
                </script>
            <?php
        });
    }
}
