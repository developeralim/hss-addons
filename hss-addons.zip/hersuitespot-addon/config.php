<?php 
    return [
        [
            'widget'      => \HerSuitespotAddons\Addons\CustomPostTypeListing::class,
            'dependency'  => [
                'styles' => [
                    'custom-post-type-css' => HERSUITESPOT_PLUGIN_URL . 'assets/post-type-listing/style.css',
                    'owl-carousel'         => HERSUITESPOT_PLUGIN_URL . 'assets/post-type-listing/owl.carousel.min.css',
                    'owl-carousel-theme'   => HERSUITESPOT_PLUGIN_URL . 'assets/post-type-listing/owl.theme.default.min.css',
                ],
                'scripts' => [
                    'custom-post-type-js' =>HERSUITESPOT_PLUGIN_URL . 'assets/post-type-listing/script.js',
                    'owl-carousel'        =>HERSUITESPOT_PLUGIN_URL . 'assets/post-type-listing/owl-carousel.min.js',
                ]
            ]
        ]
    ];