<?php

/**
 * Plugin Name: HerSuitespot Addons
 * Plugin URI:  https://github.com/developeralim/herSuitespot-Addon.git
 * Description: Elementor Addons for HerSuiteSpot
 * Version:     1.0.0
 * Author:      HerSuitespot Developer
 * Author URI:  https://github.com/developeralim
 * Text Domain: hersuitespot-addon
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 */

use HerSuitespotAddons\Controls\SortableSelect2;
use HerSuitespotAddons\Extra\AddonManager;
use HerSuitespotAddons\Extra\Admin;
use HerSuitespotAddons\Extra\Ajax;

! defined('WPINC') && die('Directly access prohibited');

if (!class_exists('HerSuitespot_Addons')) {

    #[AllowDynamicProperties]

    class HerSuitespotAddons{

        /**
         * Contains instance of HerSuitespot_Addons
         *
         * @var null|self
         */
        public static $instance = null;

        /**
         * Contains plugin url
         *
         * @var string
         */
        public string $plugin_url;

        /**
         * Refers to pluign version
         *
         * @var string
         */
        public string $version = '1.0.0';


        /**
         * Contains plugin path
         *
         * @var string
         */
        public ?string $plugin_path = null;

        /**
         * Contains plugin name
         *
         * @var string
         */
        public string $plugin_name;

        /**
         * Container to hold all addons
         *
         * @var array
         */
        public array $addons = [];

        /**
         * Addon manager
         *
         * @var AddonManager
         */
        public AddonManager $addon_manager;

        /**
         * Contains ajax
         *
         * @var Ajax
         */
        public Ajax $ajax;

        /**
         * Admin instance
         *
         * @var Admin
         */
        public Admin $admin;

        public function __construct()
        {
            $this->plugin_name = plugin_basename(__FILE__);

            $this->define_constants();
            $this->lang();
            $this->init();

            $this->addon_manager = new AddonManager( $this->addons );
            $this->ajax          = new Ajax();

            // Resource post type
            add_action( 'init',[$this,'add_admin_resource_post_type']);
            add_action( 'init', [$this,'add_admin_resource_category_taxonomy']);
            add_action( 'init', [$this,'add_admin_resource_category_tag']);

            // Funding post type
            add_action( 'init',[$this,'add_admin_funding_post_type']);
            add_action( 'init', [$this,'add_admin_funding_category_taxonomy']);
            add_action( 'init', [$this,'add_admin_funding_category_tag']);

            // register control
            add_action( 'elementor/controls/register', [$this,'hss_elementor_controls']);

            register_activation_hook(__FILE__,[$this,'activate']);
            register_deactivation_hook(__FILE__,[$this,'deactivate']);
        }

        public function lang()
        {
            load_plugin_textdomain(
                HERSUITESPOT_TEXTDOMAIN,
                false,
                dirname( plugin_basename( __FILE__ ) ) . '/languages'
            );
        }

        public function init()
        {
            require_once $this->plugin_path('autoload.php');
            $this->addons = require_once $this->plugin_path('config.php');

            add_action('wp_head',function(){
                ?>
                    <script>
                        var hersuiteAddonJS = {
                            'ajaxEndpoint' : "<?php echo admin_url('admin-ajax.php'); ?>",
                            'nonce'        : "<?php echo wp_create_nonce('hersuitespot-addon-js'); ?>"
                        }
                    </script>
                <?php
            });

            $this->admin_init();
        }

        public function hss_elementor_controls( $controls_manager )
        {
            $controls_manager->register( new SortableSelect2 );
        }

        private function admin_init()
        {
            if ( ! is_admin() ) {
                return;
            }

            $this->admin = new Admin();
        }

        private function plugin_path( $path )
        {
            if ( ! $this->plugin_path ) {
                $this->plugin_path = trailingslashit( plugin_dir_path( __FILE__ ) );
            }

            return $this->plugin_path . $path;
        }

        public function activate()
        {
            //do some stuffs when plugins activated
        }

        public function deactivate()
        {
            //Do some other stuffs
        }

        protected function define_constants()
        {
            ! defined('HERSUITESPOT_TEXTDOMAIN') && define('HERSUITESPOT_TEXTDOMAIN','hersuitespot-addons');
            ! defined('HERSUITESPOT_PLUGIN_DIR') && define('HERSUITESPOT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
            ! defined('HERSUITESPOT_PLUGIN_URL') && define('HERSUITESPOT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
            ! defined('HERSUITESPOT_PLUGIN_VERSION') && define('HERSUITESPOT_PLUGIN_VERSION',$this->version);
        }

        public static function instance()
        {
            if ( ! self::$instance ) {
                self::$instance = new self();
            }

            return self::$instance;
        }


        public function add_admin_resource_post_type()
        {
            $labels = [
                "name"               => esc_html__( "Resources", HERSUITESPOT_TEXTDOMAIN ),
                "singular_name"      => esc_html__( "Resource", HERSUITESPOT_TEXTDOMAIN ),
                "all_items"          => esc_html__( "All resources", HERSUITESPOT_TEXTDOMAIN ),
                "add_new"            => esc_html__( "Add new resource", HERSUITESPOT_TEXTDOMAIN ),
                "add_new_item"       => esc_html__( "Add new resource", HERSUITESPOT_TEXTDOMAIN ),
                "edit_item"          => esc_html__( "Edit resource", HERSUITESPOT_TEXTDOMAIN ),
                "new_item"           => esc_html__( "New resource", HERSUITESPOT_TEXTDOMAIN ),
                "view_item"          => esc_html__( "View resource", HERSUITESPOT_TEXTDOMAIN ),
                "view_items"         => esc_html__( "View resources", HERSUITESPOT_TEXTDOMAIN ),
                "search_items"       => esc_html__( "Search resource", HERSUITESPOT_TEXTDOMAIN ),
                "not_found"          => esc_html__( "No resources found", HERSUITESPOT_TEXTDOMAIN ),
                "not_found_in_trash" => esc_html__( "No resources found in trash", HERSUITESPOT_TEXTDOMAIN ),
                "parent"             => esc_html__( "Parent resource", HERSUITESPOT_TEXTDOMAIN ),
                "parent_item_colon"  => esc_html__( "Parent resource", HERSUITESPOT_TEXTDOMAIN ),
            ];

            $args = [
                "label"                 => esc_html__( "Resources", HERSUITESPOT_TEXTDOMAIN ),
                "labels"                => $labels,
                "description"           => "",
                "public"                => true,
                "publicly_queryable"    => true,
                "show_ui"               => true,
                "show_in_rest"          => true,
                "rest_base"             => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "rest_namespace"        => "wp/v2",
                "has_archive"           => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "delete_with_user"      => false,
                "exclude_from_search"   => false,
                "capability_type"       => "post",
                "map_meta_cap"          => true,
                "hierarchical"          => true,
                "can_export"            => false,
                "rewrite"               => [ "slug" => "resource", "with_front" => false ],
                "query_var"             => true,
                "menu_icon"             => "dashicons-database-view",
                "supports"              => [ "title", "editor", "thumbnail", "excerpt", "page-attributes" ],
                "taxonomies"            => [ "resource_category", "resource_tag" ],
                "show_in_graphql"       => false,
            ];

            register_post_type( "resource", $args );
        }

        public function add_admin_resource_category_taxonomy()
        {
            $labels = [
                "name"          => esc_html__( "Resource categories", HERSUITESPOT_TEXTDOMAIN ),
                "singular_name" => esc_html__( "Resource category", HERSUITESPOT_TEXTDOMAIN ),
            ];


            $args = [
                "label"                 => esc_html__( "Resource categories", HERSUITESPOT_TEXTDOMAIN ),
                "labels"                => $labels,
                "public"                => true,
                "publicly_queryable"    => true,
                "hierarchical"          => true,
                "show_ui"               => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "query_var"             => true,
                "rewrite"               => [ 'slug' => 'resource_category', 'with_front' => true, ],
                "show_admin_column"     => false,
                "show_in_rest"          => true,
                "show_tagcloud"         => false,
                "rest_base"             => "resource_category",
                "rest_controller_class" => "WP_REST_Terms_Controller",
                "rest_namespace"        => "wp/v2",
                "show_in_quick_edit"    => false,
                "sort"                  => false,
                "show_in_graphql"       => false,
            ];

            register_taxonomy( "resource_category", [ "resource" ], $args );
        }

        public function add_admin_resource_category_tag()
        {
            $labels = [
                "name"          => esc_html__( "Resource tags", HERSUITESPOT_TEXTDOMAIN ),
                "singular_name" => esc_html__( "Resource tag", HERSUITESPOT_TEXTDOMAIN ),
            ];


            $args = [
                "label"                 => esc_html__( "Resource tags", HERSUITESPOT_TEXTDOMAIN ),
                "labels"                => $labels,
                "public"                => true,
                "publicly_queryable"    => true,
                "hierarchical"          => false,
                "show_ui"               => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "query_var"             => true,
                "rewrite"               => [ 'slug' => 'resource_tag', 'with_front' => true,],
                "show_admin_column"     => false,
                "show_in_rest"          => true,
                "show_tagcloud"         => true,
                "rest_base"             => "resource_tag",
                "rest_controller_class" => "WP_REST_Terms_Controller",
                "rest_namespace"        => "wp/v2",
                "show_in_quick_edit"    => false,
                "sort"                  => false,
                "show_in_graphql"       => false,
            ];

            register_taxonomy( "resource_tag", [ "resource" ], $args );
        }

        public function add_admin_funding_post_type()
        {
            $labels = [
                "name"               => esc_html__( "Fundings", HERSUITESPOT_TEXTDOMAIN ),
                "singular_name"      => esc_html__( "Funding", HERSUITESPOT_TEXTDOMAIN ),
                "all_items"          => esc_html__( "All Fundings", HERSUITESPOT_TEXTDOMAIN ),
                "add_new"            => esc_html__( "Add new funding", HERSUITESPOT_TEXTDOMAIN ),
                "add_new_item"       => esc_html__( "Add new funding", HERSUITESPOT_TEXTDOMAIN ),
                "edit_item"          => esc_html__( "Edit funding", HERSUITESPOT_TEXTDOMAIN ),
                "new_item"           => esc_html__( "New funding", HERSUITESPOT_TEXTDOMAIN ),
                "view_item"          => esc_html__( "View funding", HERSUITESPOT_TEXTDOMAIN ),
                "view_items"         => esc_html__( "View fundings", HERSUITESPOT_TEXTDOMAIN ),
                "search_items"       => esc_html__( "Search funding", HERSUITESPOT_TEXTDOMAIN ),
                "not_found"          => esc_html__( "No fundings found", HERSUITESPOT_TEXTDOMAIN ),
                "not_found_in_trash" => esc_html__( "No fundings found in trash", HERSUITESPOT_TEXTDOMAIN ),
                "parent"             => esc_html__( "Parent funding", HERSUITESPOT_TEXTDOMAIN ),
                "parent_item_colon"  => esc_html__( "Parent funding", HERSUITESPOT_TEXTDOMAIN ),
            ];

            $args = [
                "label"                 => esc_html__( "Fundings", HERSUITESPOT_TEXTDOMAIN ),
                "labels"                => $labels,
                "description"           => "",
                "public"                => true,
                "publicly_queryable"    => true,
                "show_ui"               => true,
                "show_in_rest"          => true,
                "rest_base"             => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "rest_namespace"        => "wp/v2",
                "has_archive"           => false,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "delete_with_user"      => false,
                "exclude_from_search"   => false,
                "capability_type"       => "post",
                "map_meta_cap"          => true,
                "hierarchical"          => true,
                "can_export"            => false,
                "rewrite"               => [ "slug" => "funding", "with_front" => true ],
                "query_var"             => true,
                "menu_icon"             => "dashicons-buddicons-tracking",
                "supports"              => [ "title", "editor", "thumbnail", "excerpt", "page-attributes" ],
                "taxonomies"            => [ "funding_category", "funding_tag" ],
                "show_in_graphql"       => false,
            ];

            register_post_type( "funding", $args );
        }

        public function add_admin_funding_category_taxonomy()
        {
            $labels = [
                "name"          => esc_html__( "Funding categories", HERSUITESPOT_TEXTDOMAIN ),
                "singular_name" => esc_html__( "Funding category", HERSUITESPOT_TEXTDOMAIN ),
            ];


            $args = [
                "label"                 => esc_html__( "Funding categories", HERSUITESPOT_TEXTDOMAIN ),
                "labels"                => $labels,
                "public"                => true,
                "publicly_queryable"    => true,
                "hierarchical"          => true,
                "show_ui"               => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "query_var"             => true,
                "rewrite"               => [ 'slug' => 'funding_category', 'with_front' => true, ],
                "show_admin_column"     => false,
                "show_in_rest"          => true,
                "show_tagcloud"         => false,
                "rest_base"             => "funding_category",
                "rest_controller_class" => "WP_REST_Terms_Controller",
                "rest_namespace"        => "wp/v2",
                "show_in_quick_edit"    => false,
                "sort"                  => false,
                "show_in_graphql"       => false,
            ];

            register_taxonomy( "funding_category", [ "funding" ], $args );
        }

        public function add_admin_funding_category_tag()
        {
            $labels = [
                "name"          => esc_html__( "Funding tags", HERSUITESPOT_TEXTDOMAIN ),
                "singular_name" => esc_html__( "Funding tag", HERSUITESPOT_TEXTDOMAIN ),
            ];


            $args = [
                "label"                 => esc_html__( "Funding tags", HERSUITESPOT_TEXTDOMAIN ),
                "labels"                => $labels,
                "public"                => true,
                "publicly_queryable"    => true,
                "hierarchical"          => false,
                "show_ui"               => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "query_var"             => true,
                "rewrite"               => [ 'slug' => 'funding_tag', 'with_front' => true,],
                "show_admin_column"     => false,
                "show_in_rest"          => true,
                "show_tagcloud"         => true,
                "rest_base"             => "funding_tag",
                "rest_controller_class" => "WP_REST_Terms_Controller",
                "rest_namespace"        => "wp/v2",
                "show_in_quick_edit"    => false,
                "sort"                  => false,
                "show_in_graphql"       => false,
            ];

            register_taxonomy( "funding_tag", [ "funding" ], $args );
        }
    }



    if ( ! function_exists('hersuitespot_addons') ) {
        function hersuitespot_addons()
        {
            return HerSuitespotAddons::instance();
        }
    }
}

add_action("plugins_loaded","hersuitespot_addons");
