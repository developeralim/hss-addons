(function($){

    var Admin = {

        init : () => {
            Admin.initBrandMetaBox();

            $('.make__featured').on('click',function(e){
                e.preventDefault();
                $.ajax({
                    url    : ajaxurl,
                    method : 'POST',
                    data   : {
                        'action' : 'featured_action',
                        'nonce'  : $(this).data('nonce'),
                        'id'     : $(this).data('id'),
                        'status' : $(this).data('status')
                    },
                    success : function(){
                        window.location.replace( window.location.href );
                    }
                });
            });

        },

        initBrandMetaBox : () => {
            var frame,
                metaBox = $('#brand_image_meta_box.postbox'),
                addImgLink = metaBox.find('.brand_upload_btn'),
                imgContainer = metaBox.find('.meta-image'),
                img = metaBox.find('img');

            addImgLink.on('click', function (event) {
                event.preventDefault();
                
                if (frame) {
                    frame.open();
                    return;
                }
                
                frame = wp.media({
                    title: 'Select or Upload Image',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false  // Set to true to allow multiple images to be selected
                });
            
                frame.on('select', function () {
                    // Get media attachment details from the frame state
                    var attachment = frame.state().get('selection').first().toJSON();
                    
                    // Send the attachment URL to our custom image input field
                    imgContainer.val(attachment.url).change();
                    img.attr('src',attachment.url);
                });
        
                // Finally, open the modal on click
                frame.open();
            });
        }
    }

    $(document).ready(function(){Admin.init()});

}(jQuery));