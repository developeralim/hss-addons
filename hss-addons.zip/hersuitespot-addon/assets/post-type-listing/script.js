(function( factory,timeout = 1000 ){
    jQuery(document).ready(function(){
        if ( typeof elementor !== 'undefined' ) {
            elementor.on('document:loaded',() => {
                setTimeout(() => factory(jQuery), timeout);
            });
        } else {
            factory(jQuery)
        }
    });
}(function( $ ){

    var element = $('.cm__post__listing'),        
        CustomPostTypeListing = {

            init : () => {
            
                // Dropdown toggle 
                $(document).on('click',function(e){

                    if ( 
                        $(e.target).hasClass('txonomy__dropdown') || 
                        $('.dropdown__option').has( e.target ).length > 0 
                    ) {
                        $('.dropdown__option').removeClass('show');
                        return $(e.target).find('.dropdown__option').addClass('show')
                    }

                    $('.dropdown__option').removeClass('show');
                });   


                $('.filter').find('input[type="checkbox"], select').on('change',function(){

                    let type = $(this).data('type');
                    let name = $(this).attr('name');

                    switch( type ) {
                        case "order" : 
                        case "limit" :
                            filterOptions[name] = $(this).val();

                            break;
                        case "taxonomies" :

                            filterOptions.taxonomies[name]  = $(`input[name="${name}"]:checked`).map(( index,item ) => {
                                return $(item).val();
                            }).toArray()

                            break;
                    }

                    CustomPostTypeListing.filter();
                });

                $(document).on('click','.pagination__area',function(e){
                    
                    if ( ! $(e.target).hasClass('page') ) {
                        return;
                    }

                    e.preventDefault();

                    let page        = $(e.target).data('page');
                    let currentPage = parseInt(filterOptions.page);
                    let totalPages  = parseInt(filterOptions.pages);

                    if ( page == 'next' ) {
                        currentPage += 1;
                    } else if ( page == 'prev' ) {
                        currentPage -= 1;
                    } else {
                        currentPage = page;
                    }


                    if ( currentPage > totalPages ) {
                        return;
                    }

                    if ( currentPage <= 0 ) {
                        currentPage = 1;
                        return;
                    }


                    filterOptions.page = currentPage;
                    
                    $(this).find('.active').removeClass('active');
                    $(this).find(`[data-page="${currentPage}"]`).addClass('active');

                    CustomPostTypeListing.filter();
                });

                // Real time search
                $(document).on('input','#cp__search',function(){
                    var search = $(this).val().trim().toLowerCase();

                    if ( search == '' || search == null ) {
                        return $('.cm__list__item').show();
                    }


                    $('.general__area').find('.cm__list__item').each((index,item) => {

                        let title    = $(item).data('title').trim().toLowerCase();
                        let taxonomy = $(item).data('taxonomy').trim().toLowerCase();
                        let excerpt  = $(item).data('excerpt').trim().toLowerCase();
                        
                        if ( title.includes( search ) || taxonomy.includes( search ) || excerpt.includes( search ) ) {
                            return $(item).show();
                        }

                        $(item).hide();

                    });

                });

                CustomPostTypeListing.initBrandMetaBox();
                CustomPostTypeListing.filter();
            },

            filter : () => {
                $.ajax({
                    url        : hersuiteAddonJS.ajaxEndpoint,
                    method     : 'POST',
                    beforeSend : () => {
                        $('#preloader').show();
                    },
                    complete   : () => {
                        $('#preloader').hide();
                    },
                    
                    data       : $.extend(
                        {},
                        {
                            'nonce'  : hersuiteAddonJS.nonce,
                            'action' : 'filter_custom_post_type_data'
                        },
                        filterOptions
                    ),

                    success     : function(data){
                        var { post_items,paginations,total_pages } = data.data;

                        $('.general__area').html(post_items);
                        $('.pagination__area').html(paginations);

                        filterOptions.pages = total_pages;
                    }
                });
            },
            initBrandMetaBox : () => {
                var frame,
                    metaBox = $('#brand_image_meta_box.postbox'),
                    addImgLink = metaBox.find('.brand_upload_btn'),
                    imgContainer = metaBox.find('.meta-image');

                addImgLink.on('click', function (event) {
                    event.preventDefault();
                    
                    if (frame) {
                        frame.open();
                        return;
                    }
                    
                    frame = wp.media({
                        title: 'Select or Upload Image',
                        button: {
                            text: 'Use this image'
                        },
                        multiple: false  // Set to true to allow multiple images to be selected
                    });
                
                    frame.on('select', function () {
                        // Get media attachment details from the frame state
                        var attachment = frame.state().get('selection').first().toJSON();
                        
                        console.log(attachment);

                        // Send the attachment URL to our custom image input field
                        imgContainer.val(attachment.url).change();
                    });
            
                    // Finally, open the modal on click
                    frame.open();
                });
            }
        };

    CustomPostTypeListing.init();
}));