(function ($) {

    $(document).ready(function () {

        var SortableSelect2 = elementor.modules.controls.BaseData.extend({
            onReady: function () {
                this.control_select = this.$el.find('.hss__select2__sortable');

                var control = this;

                this.control_select.select2({
                    placeholder: 'Select Order'
                }).on("select2:select", function (evt) {
                    var id = evt.params.data.id;

                    var element = $(this).children("option[value=" + id + "]");

                    moveElementToEndOfParent(element);

                    $(this).trigger("change");

                    control.saveValue();
                });

                var ele = this.control_select.parent().find("ul.select2-selection__rendered");

                ele.sortable({
                    containment: 'parent',
                    update: function () {
                        orderSortedValues();
                    }
                });

                orderSortedValues = function () {
                    var value = ''
                    this.control_select.parent().find("ul.select2-selection__rendered").children("li[title]").each(function (i, obj) {

                        var element = this.control_select.children('option').filter(function () { return $(this).html() == obj.title });
                        moveElementToEndOfParent(element)
                    });
                };

                moveElementToEndOfParent = function (element) {
                    var parent = element.parent();

                    element.detach();

                    parent.append(element);
                };

            },

            saveValue : function(){
                this.setValue( this.control_select.val() );
            },

            onBeforeDestroy : function(){
                this.saveValue();
            }
        });

        elementor.addControlView('__SORTABLE_SELECT2__', SortableSelect2);
    })

}(jQuery));
